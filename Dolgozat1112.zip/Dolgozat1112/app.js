import express from "express";
import {
  deleteEquipment,
  editEquipment,
  getEquipmentByCategory,
  getEquipmentById,
} from "./data/db.js";

const app = express();
const PORT = 3000;

app.use(express.json());

app.get("/api/equipment/:id", (req, res) => {
  const id = +req.params.id;
  const equipment = getEquipmentById(id);

  if (!equipment) {
    return res.status(404).json({ message: "Equipment not found." });
  }
  res.status(200).json(equipment);
});

app.get("/api/equipment/category/:category", (req, res) => {
  const category = req.params.category;
  const equipment = getEquipmentByCategory(category);

  if (equipment.length == 0) {
    return res.status(404).json({ message: "Equipment not found." });
  }
  res.status(200).json(equipment);
});

app.put("/api/equipment/:id", (req, res) => {
  const id = +req.params.id;
  const equipment = getEquipmentById(id);
  const { name, category, brand, price, quantity } = req.body;

  if (!equipment) {
    return res.status(404).json({ message: "Equipment not found." });
  }

  if (category == "") {
    return res.status(400).json({ message: "Category can NOT be empty!" });
  } else if (brand == "") {
    return res.status(400).json({ message: "Brand can NOT be empty!" });
  }
  if (price <= 0) {
    return res
      .status(400)
      .json({ message: "Price can NOT be negative or zero." });
  }

  if (quantity < 0) {
    return res.status(400).json({ message: "Quantity can NOT be negative." });
  }

  if (!name || !category || !brand || !price || !quantity) {
    return res.status(400).json({ message: "All datas required!" });
  }

  const newEq = editEquipment(name, category, brand, price, quantity, id);
  res.status(200).json({
    id: id,
    name: name,
    category: category,
    brand: brand,
    price: price,
    quantity: quantity,
  });
});

app.delete("/api/equipment/:id", (req, res) => {
  const id = +req.params.id;
  const equipment = getEquipmentById(id);

  if (!equipment) {
    return res.status(404).json({ message: "Equipment not found." });
  }
  deleteEquipment(id);

  res.status(200).json({ message: "Equipment successfully deleted." });
});

app.listen(PORT, () => {
  console.log("A szerver fut a " + PORT + "-es porton.");
});
