import Database from "better-sqlite3";

const db = new Database("./data/sports.db");

/* 
id    INTEGER    Elsődleges kulcs, AUTO INCREMENT
name    TEXT    Sportfelszerelés neve
category    TEXT    Kategória
brand    TEXT    Márka
price    REAL    Ár (Ft)
quantity    INTEGER    Raktáron lévő darabszám */

export const getEquipmentById = (id) => {
  return db.prepare(`SELECT * FROM equipments WHERE id=?`).get(id);
};

export const getEquipmentByCategory = (category) => {
  return db.prepare(`SELECT * FROM equipments WHERE category=?`).all(category);
};

export const editEquipment = (name, category, brand, price, quantity, id) => {
  return db
    .prepare(
      `UPDATE equipments SET name=?, category=?, brand=?, price=?, quantity=? WHERE id=?`,
    )
    .run(name, category, brand, price, quantity, id);
};

export const deleteEquipment = (id) => {
  return db.prepare(`DELETE FROM equipments  WHERE id=?`).run(id);
};
